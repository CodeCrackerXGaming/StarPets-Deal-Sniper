const v20 = document.createElement("script");
v20.id = "whqtt";
v20.src = (chrome || browser).runtime.getURL("main.js");
fetch((chrome || browser).runtime.getURL("identity.txt")).then(p7 => {
  p7.text().then(p8 => {
    v20.setAttribute("identity", p8);
    document.documentElement.append(v20);
  });
});
v20.onload = () => {
  v20.remove();
};